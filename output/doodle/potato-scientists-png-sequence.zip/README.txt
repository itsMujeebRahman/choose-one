50 transparent RGBA PNG frames. Canvas 512 x 288. Play at 10 fps for 5 seconds. Frame duration 100ms. Loop indefinitely. Converted from the supplied MP4, not a vector/Lottie animation.
